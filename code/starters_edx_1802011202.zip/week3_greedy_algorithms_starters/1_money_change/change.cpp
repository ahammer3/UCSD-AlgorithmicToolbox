#include <iostream>

int get_change(int m) {
  //write your code here
  return n;
}

int main() {
  int m;
  std::cin >> m;
  std::cout << get_change(m) << '\n';
}
